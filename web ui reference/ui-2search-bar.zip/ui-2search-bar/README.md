# UI #2 - Search Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/AlbertFeynman/pen/BPvzWZ](https://codepen.io/AlbertFeynman/pen/BPvzWZ).

Animated search bar