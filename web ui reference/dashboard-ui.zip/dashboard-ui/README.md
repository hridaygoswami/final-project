# Dashboard UI 

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/jOwJWOG](https://codepen.io/havardob/pen/jOwJWOG).

A dashboard concept designed by Jordan Hughes: https://dribbble.com/shots/16506804/attachments/11468776?mode=media

Icons from https://phosphoricons.com/

Logos from https://worldvectorlogo.com/