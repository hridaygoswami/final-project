# Animated input search

A Pen created on CodePen.io. Original URL: [https://codepen.io/co0kie/pen/YzyZBqb](https://codepen.io/co0kie/pen/YzyZBqb).

