# Nice, compliant input boxes

A Pen created on CodePen.io. Original URL: [https://codepen.io/atunnecliffe/pen/gpKzQw](https://codepen.io/atunnecliffe/pen/gpKzQw).

Nice input box with a lot of styling based on sibling selectors and psuedo classes. 

CSS only, and WCAG 2.0 AA compliant!